var x = "X";
var experimentalVariable = 0;
var move;
function crossNullButton(cell){
	crosskletka = document.getElementById(cell)
	if (experimentalVariable == 0 
	 || experimentalVariable == 2
	 || experimentalVariable == 4
	 || experimentalVariable == 6
	 || experimentalVariable == 8) {
		x = "X"
		var moveplayer = "Сейчас ход игрока 2"
		crosskletka.innerHTML = x
		move = document.getElementById("whoseMoveWin")
		move.innerHTML = moveplayer
	}
	else if (experimentalVariable == 1
		  || experimentalVariable == 3
	 	  || experimentalVariable == 5
	 	  || experimentalVariable == 7) {
		x = 0
		var moveplayer = "Сейчас ход игрока 1"
		crosskletka.innerHTML = x
		move = document.getElementById("whoseMoveWin")
		move.innerHTML = moveplayer
	}
	experimentalVariable++
	console.log(experimentalVariable)
}